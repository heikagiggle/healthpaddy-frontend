"use client";

export type LinkPropsObject = {
  key: string;
  name: string;
};

export type LinkProp = Array<LinkPropsObject>;

export const users: LinkProp = [
  { name: "Blessing", key: "blessing" },
  { name: "Ava", key: "ava" },
  { name: "Olivia", key: "olivia" },
];


export const customers = [
  {
    name: "Adebimpe",
    age: 27,
    energyNeeds: "2000 kcal per day",
    healthGoal: "Weight Gain",
    imageUrl: "https://files.skillpaddy.com/public/image/lady-1728480679260.png" // example image path
  },
  {
    name: "Blessing",
    age: 29,
    energyNeeds: "1800 kcal per day",
    healthGoal: "Maintain Weight",
    imageUrl: "https://files.skillpaddy.com/public/image/lady-1728480679260.png"
  },
  {
    name: "Ava",
    age: 31,
    energyNeeds: "2200 kcal per day",
    healthGoal: "Lose Weight",
    imageUrl: "https://files.skillpaddy.com/public/image/lady-1728480679260.png"
  }
];