"use client";
import TestimonialTabs from "./component/testimonial-tabs";

const MeetUsers = () => {
 
  return (
    <div className="container mx-auto my-16">
    <TestimonialTabs />
  </div>
  );
};

export default MeetUsers;
