export interface ContainerProps {
    onNextStep?: () => void;
    onPrevStep: () => void;
  }