export type IconProps = {
    className?: string;
    primaryColor?: string;
    secondaryColor?: string;
    active?: boolean;
    fill?: string;
  };